import mongoose from 'mongoose';
export const connectDB = async (uri) => {
  if (!uri) throw new Error('MONGO_URI not provided');
  if (mongoose.connection.readyState === 1) return mongoose.connection;
  return mongoose.connect(uri, { dbName: 'love_shop' });
};
