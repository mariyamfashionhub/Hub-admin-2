import 'dotenv/config';
import { connectDB } from '../config/db.js';
import Product from '../models/Product.js';
import User from '../models/User.js';
const run = async () => {
  await connectDB(process.env.MONGO_URI || 'mongodb://localhost:27017/love_shop');
  await Product.deleteMany({});
  await User.deleteMany({});
  await User.create([
    { name:'Admin', email:'admin@example.com', password:'Admin@123', role:'admin' },
    { name:'Staff', email:'staff@example.com', password:'Staff@123', role:'staff' },
    { name:'Customer', email:'cust@example.com', password:'Cust@123', role:'customer' }
  ]);
  await Product.create([
    { sku:'P001', name:'Red Dress', price:1999, cost:900, stock:20 },
    { sku:'P002', name:'Blue Shirt', price:999, cost:400, stock:35 }
  ]);
  console.log('✅ Seeded admin/staff/customer and products'); process.exit(0);
};
run();