import mongoose from 'mongoose';
const productSchema = new mongoose.Schema({
  sku: { type: String, unique: true, required: true },
  name: { type: String, required: true },
  price: { type: Number, required: true },
  cost: { type: Number, default: 0 },
  stock: { type: Number, default: 0 },
  sold: { type: Number, default: 0 },
  returned: { type: Number, default: 0 },
  damaged: { type: Number, default: 0 }
}, { timestamps: true });
export default mongoose.model('Product', productSchema);
