import { Router } from 'express';
import { list, create, update, remove, adjustStock } from '../controllers/productController.js';
const router = Router();
router.get('/', list);
router.post('/', create);
router.put('/:id', update);
router.delete('/:id', remove);
router.post('/:id/adjust', adjustStock);
export default router;
