import Product from '../models/Product.js';
export const list = async (req,res)=>{ try{ const items = await Product.find().sort('-createdAt'); res.json(items); }catch(err){ res.status(500).json({message:err.message}); } };
export const create = async (req,res)=>{ try{ const p = await Product.create(req.body); res.json(p); }catch(err){ res.status(500).json({message:err.message}); } };
export const update = async (req,res)=>{ try{ const p = await Product.findByIdAndUpdate(req.params.id, req.body, { new:true }); res.json(p); }catch(err){ res.status(500).json({message:err.message}); } };
export const remove = async (req,res)=>{ try{ await Product.findByIdAndDelete(req.params.id); res.json({message:'Deleted'}); }catch(err){ res.status(500).json({message:err.message}); } };
export const adjustStock = async (req,res)=>{ try{
  const { type, quantity } = req.body;
  const p = await Product.findById(req.params.id);
  if(!p) return res.status(404).json({message:'Not found'});
  const qty = Number(quantity || 0);
  if(type==='return'){ p.stock += qty; p.returned += qty; }
  else if(type==='damage'){ if(p.stock < qty) return res.status(400).json({message:'Insufficient stock'}); p.stock -= qty; p.damaged += qty; }
  await p.save();
  res.json(p);
}catch(err){ res.status(500).json({message:err.message}); } };
