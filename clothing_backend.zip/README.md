Clothing Backend (ready)

Quick start:
  cp .env.example .env
  npm install
  npm run seed
  npm start

API:
  GET /_health
  POST /api/auth/register
  POST /api/auth/login
  GET /api/products
  POST /api/products
  POST /api/products/:id/adjust  { type: 'return'|'damage', quantity }
