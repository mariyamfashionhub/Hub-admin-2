import React from 'react';
export default function Home() {
  return <h1>Welcome to Mariyam Fashion</h1>;
}
